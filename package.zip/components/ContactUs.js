import React, { Component } from "react";

export class Contactus extends Component {
  render() {
    return (
      <div className="container-fluid whole-background pb-5" id="contactus">
        <div className="container">
          <div className="row ">
            <div className="col-md-6 ml-4"></div>
          </div>
        </div>
        <div className="row">
          <div className="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-8">
            <img className="img imgg-css" src="/pic.Jpeg" alt="logo" />
          </div>
          <div className="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-4 pl-4 mt-5">
            <form>
              <div className="">
                <div className="card-body p-3">
                  <div className="about-left my-3">
                    <div className="icon">
                      <h4>
                        Get In <strong> Touch </strong>
                        <br />
                        With Us
                      </h4>
                    </div>
                  </div>
                  <div className="form-group">
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fa fa-user icon"></i>
                        </div>
                      </div>
                      <input
                        type="text"
                        className="form-control"
                        id="nombre"
                        name="nombre"
                        placeholder="User name"
                        required
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fa fa-envelope icon"></i>
                        </div>
                      </div>
                      <input
                        type="email"
                        className="form-control"
                        id="nombre"
                        name="email"
                        placeholder="example@gmail.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <div className="input-group mb-2">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <i className="fa fa-comment icon"></i>
                        </div>
                      </div>
                      <textarea
                        className="form-control"
                        placeholder="Write your message"
                        required
                      ></textarea>
                    </div>
                  </div>

                  <div className="text-center">
                    <button
                      type="submit"
                      className="btn btn-warning btn-block rounded-5 py-2 text-white"
                    >
                      <i className="fa fa-paper-plane text-white pr-3"></i>
                      Send
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div className="row">
          <footer
            className="section footer-classic context-dark bg-image"
            style={{ background: "#3f3d55", marginBottom: 0 }}
          >
            <div className="container py-5">
              <div className="row row-30">
                <div className="col-md-4 col-xl-5">
                  <div className="pr-xl-4">
                    <a className="brand" href="index.html">
                      <img
                        className="brand-logo-light"
                        src="/logo.png"
                        alt=""
                        width="140"
                        height="37"
                      />
                    </a>
                    <p>
                      We are an award-winning creative agency, dedicated to the
                      best result in web design, promotion, business consulting,
                      and marketing.
                    </p>

                    <p className="rights">
                      <span>©  </span>
                      <span className="copyright-year">2018</span>
                      <span> </span>
                      <span>Waves</span>
                      <span>. </span>
                      <span>All Rights Reserved.</span>
                    </p>
                  </div>
                </div>
                <div className="col-md-4">
                  <h5>Contacts</h5>
                  <dl className="contact-list">
                    <dt>Address:</dt>
                    <dd>798 South Park Avenue, Jaipur, Raj</dd>
                  </dl>
                  <dl className="contact-list">
                    <dt>email:</dt>
                    <dd>
                      <a href="mailto:#">example@gmail.com</a>
                    </dd>
                  </dl>
                  <dl className="contact-list">
                    <dt>phones:</dt>
                    <dd>
                      <a href="tel:#">https://karosearch.com</a> <span>or</span>{" "}
                      <a href="tel:#">https://karosearch.com</a>
                    </dd>
                  </dl>
                </div>
                <div className="col-md-4 col-xl-3">
                  <h5 className="pl-4">About us</h5>
                  <ul className="nav-list">
                    <li>
                      <a href="#">
                        <i className="fa fa-globe-asia icon"></i> Accross all
                        over
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="far fa-envelope icon"></i> Email
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fas fa-phone icon"></i> Call Us
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="row no-gutters social-container">
              <div className="col">
                <a className="social-inner" href="https://facebook.com">
                  <span className="icon mdi mdi-facebook"></span>
                  <span>Facebook</span>
                </a>
              </div>
              <div className="col">
                <a className="social-inner" href="https://instagram.com">
                  <span className="icon mdi mdi-instagram"></span>
                  <span>instagram</span>
                </a>
              </div>
              <div className="col">
                <a className="social-inner" href="https://twitter.com">
                  <span className="icon mdi mdi-twitter"></span>
                  <span>twitter</span>
                </a>
              </div>
              <div className="col">
                <a className="social-inner" href="https://youtube.com">
                  <span className="icon mdi mdi-youtube-play"></span>
                  <span>google</span>
                </a>
              </div>
            </div>
          </footer>
          {/* <div className="row  pt-5">
              <div className="col-1 pt-1">
              
              </div>
              <div className="col-9">
                <h1 className="home-logo-css"> Services Across Pakistan</h1>
              </div>
            </div>
            <div className="row pt-3">
              <div className="col-1 pt-2">
                <i className="far fa-envelope icon"></i>
              </div>
              <div className="col-9">
                <h1 className="home-logo-css pt-2"> Best Quality </h1>
              </div>
            </div>
            <div className="row pt-3">
              <div className="col-1">
              
              </div>
              <div className="col-9">
                <h1 className="home-logo-css ">Best Offers</h1>
              </div>
            </div> */}
        </div>
      </div>
    );
  }
}

export default Contactus;
