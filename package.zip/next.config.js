module.exports = {
  env: {
    BASE_URL: "http://localhost:3000",
    MONGODB_URL:
    "mongodb+srv://rimi:wHma1uz7FQvoV4fK@cluster0.gopth.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
      JWT_SECRET: "C-Bm:eHGh_dn=ZdY/g4Bz.8[-~yYJ6Y3m<86J`?qDg(mBq*Smc",
    REFRESH_TOKEN_SECRET:
      "/s;]BXT*GJ5q,.[hE]=J]d;##H&mt//f[G;Uvf.N2?9*!P.x5rnCD?pEt@WC",
    PAYPAL_CLIENT_ID: "AViKAUgXDtqFVZCEZizPLve6bFsHfH8ki4f3m7naB6RwdB1W8oCvkS-BTF1jIy3eV464fgAj5gT_oZrP",
    CLOUD_UPDATE_PRESET: "Next_Ecommerece",
    CLOUD_NAME: "usamacloud",
    CLOUD_API: "https://api.cloudinary.com/v1_1/usamacloud/image/upload", 
  }, 
};
 